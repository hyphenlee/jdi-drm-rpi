#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

#ifdef CONFIG_UNWINDER_ORC
#include <asm/orc_header.h>
ORC_HEADER;
#endif

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

KSYMTAB_FUNC(jdi_memory_set_invert, "_gpl", "");
KSYMTAB_FUNC(jdi_memory_add_overlay, "_gpl", "");
KSYMTAB_FUNC(jdi_memory_remove_overlay, "_gpl", "");
KSYMTAB_FUNC(jdi_memory_show_overlay, "_gpl", "");
KSYMTAB_FUNC(jdi_memory_hide_overlay, "_gpl", "");
KSYMTAB_FUNC(jdi_memory_clear_overlays, "_gpl", "");

SYMBOL_CRC(jdi_memory_set_invert, 0x2cd8420d, "_gpl");
SYMBOL_CRC(jdi_memory_add_overlay, 0x7e401cf5, "_gpl");
SYMBOL_CRC(jdi_memory_remove_overlay, 0x5f072a4f, "_gpl");
SYMBOL_CRC(jdi_memory_show_overlay, 0x92d81abe, "_gpl");
SYMBOL_CRC(jdi_memory_hide_overlay, 0x0ed93121, "_gpl");
SYMBOL_CRC(jdi_memory_clear_overlays, 0x9f1c2f88, "_gpl");

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xd3abe05, "drm_open" },
	{ 0x2a849a0b, "drm_poll" },
	{ 0xf21f2fe, "drm_gem_fb_end_cpu_access" },
	{ 0x2a3508ab, "drm_dev_enter" },
	{ 0xfed7ef5e, "devm_kmalloc" },
	{ 0xa338db8, "gpiod_set_value" },
	{ 0xa0598ccd, "drm_plane_enable_fb_damage_clips" },
	{ 0x96d101d4, "drm_atomic_helper_shutdown" },
	{ 0x37a0cba, "kfree" },
	{ 0xc464cb42, "drm_connector_helper_get_modes_fixed" },
	{ 0xc3055d20, "usleep_range_state" },
	{ 0xba102097, "devm_gpiod_get_optional" },
	{ 0x82ee90dc, "timer_delete_sync" },
	{ 0xf72eadd1, "drm_fb_dma_get_gem_obj" },
	{ 0xde8d6d59, "drmm_mode_config_init" },
	{ 0x8eb492a6, "devm_gpiod_put" },
	{ 0x122c3a7e, "_printk" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xf9bd8154, "drm_atomic_helper_commit" },
	{ 0xed77bc38, "drm_atomic_helper_check" },
	{ 0x5119cb31, "drm_atomic_helper_connector_destroy_state" },
	{ 0x7441311d, "drm_gem_mmap" },
	{ 0x9e19fade, "drm_ioctl" },
	{ 0x80f094e, "spi_sync" },
	{ 0x339e85b5, "drm_dev_unplug" },
	{ 0x6b0d711b, "drm_connector_init" },
	{ 0x8c8569cb, "kstrtoint" },
	{ 0xf474aac7, "drm_atomic_helper_damage_merged" },
	{ 0xc38c83b8, "mod_timer" },
	{ 0x7e4943a0, "noop_llseek" },
	{ 0x8bd71bb5, "drm_read" },
	{ 0x6fff7a2e, "drm_gem_fb_create_with_dirty" },
	{ 0x2b0340c2, "drm_gem_dma_dumb_create" },
	{ 0x6447069e, "driver_unregister" },
	{ 0xe8a034df, "drm_dev_exit" },
	{ 0x617a3b1f, "__devm_drm_dev_alloc" },
	{ 0xdcb764ad, "memset" },
	{ 0x631e8912, "_dev_warn" },
	{ 0xa9c1a2c7, "drm_fb_xrgb8888_to_rgb888" },
	{ 0x218f96ce, "drm_fbdev_generic_setup" },
	{ 0xe4862761, "drm_atomic_helper_connector_duplicate_state" },
	{ 0xc73306d7, "drm_simple_display_pipe_init" },
	{ 0xdfd1616e, "drm_connector_cleanup" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x5bad0d97, "dma_set_coherent_mask" },
	{ 0xd6112f8d, "param_set_int" },
	{ 0x3aba0d44, "drm_gem_fb_begin_cpu_access" },
	{ 0xc6f46339, "init_timer_key" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0xb691cfc8, "__spi_register_driver" },
	{ 0x66b4cc41, "kmemdup" },
	{ 0xd75d80c7, "devm_gpiod_get" },
	{ 0xd5e14ff7, "drm_helper_probe_single_connector_modes" },
	{ 0x12a4e128, "__arch_copy_from_user" },
	{ 0xcdf1dad, "dma_set_mask" },
	{ 0x6837b116, "drm_atomic_helper_connector_reset" },
	{ 0x468e3817, "dev_err_probe" },
	{ 0x4bcf5398, "drm_mode_config_reset" },
	{ 0x524edeca, "drm_gem_dma_prime_import_sg_table_vmap" },
	{ 0x4f5aca9b, "kmalloc_trace" },
	{ 0x4f090d86, "param_get_int" },
	{ 0xeaff7f0f, "drm_compat_ioctl" },
	{ 0x96d89242, "drm_dev_register" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0xa35b93f4, "kmalloc_caches" },
	{ 0x1c97b51e, "drm_release" },
	{ 0xe478ef45, "module_layout" },
};

MODULE_INFO(depends, "drm,drm_kms_helper,drm_dma_helper");


MODULE_INFO(srcversion, "0F4BD3678A99D378E5D46AE");
