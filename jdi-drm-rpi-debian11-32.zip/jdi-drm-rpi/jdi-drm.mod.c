#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

SYMBOL_CRC(jdi_memory_add_overlay, 0x7e401cf5, "_gpl");
SYMBOL_CRC(jdi_memory_clear_overlays, 0x7fffffff, "_gpl");
SYMBOL_CRC(jdi_memory_hide_overlay, 0x0ed93121, "_gpl");
SYMBOL_CRC(jdi_memory_remove_overlay, 0x5f072a4f, "_gpl");
SYMBOL_CRC(jdi_memory_set_invert, 0x2cd8420d, "_gpl");
SYMBOL_CRC(jdi_memory_show_overlay, 0x7fffffff, "_gpl");

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x92ba6d64, "drm_open" },
	{ 0x2e2943f3, "drm_poll" },
	{ 0x833b18c5, "drm_gem_fb_end_cpu_access" },
	{ 0xf056b15, "drm_dev_enter" },
	{ 0xc4bda6b9, "devm_kmalloc" },
	{ 0xf71f9335, "gpiod_set_value" },
	{ 0xff02f09f, "drm_plane_enable_fb_damage_clips" },
	{ 0x8f678b07, "__stack_chk_guard" },
	{ 0xefd6cf06, "__aeabi_unwind_cpp_pr0" },
	{ 0xc58e665f, "drm_gem_prime_mmap" },
	{ 0x12e15865, "drm_atomic_helper_shutdown" },
	{ 0x37a0cba, "kfree" },
	{ 0x42f7ef0b, "drm_connector_helper_get_modes_fixed" },
	{ 0x2cfde9a2, "warn_slowpath_fmt" },
	{ 0xc3055d20, "usleep_range_state" },
	{ 0xd7a0acf7, "devm_gpiod_get_optional" },
	{ 0x45e061e4, "drm_fb_dma_get_gem_obj" },
	{ 0x603c86af, "drm_gem_prime_handle_to_fd" },
	{ 0xdae4f262, "drmm_mode_config_init" },
	{ 0xd913bc34, "devm_gpiod_put" },
	{ 0x92997ed8, "_printk" },
	{ 0x3ea1b6e4, "__stack_chk_fail" },
	{ 0xf8e73195, "drm_atomic_helper_commit" },
	{ 0xa1b75808, "drm_atomic_helper_check" },
	{ 0xf72cdba7, "drm_atomic_helper_connector_destroy_state" },
	{ 0x12e884b7, "drm_gem_mmap" },
	{ 0x439f580e, "drm_ioctl" },
	{ 0xc07946ce, "drm_gem_prime_fd_to_handle" },
	{ 0x87c213a1, "spi_sync" },
	{ 0xf440f35b, "drm_dev_unplug" },
	{ 0x31a2a4dd, "drm_connector_init" },
	{ 0x8e865d3c, "arm_delay_ops" },
	{ 0x8c8569cb, "kstrtoint" },
	{ 0x1869402, "drm_atomic_helper_damage_merged" },
	{ 0xc38c83b8, "mod_timer" },
	{ 0x2b54823f, "noop_llseek" },
	{ 0x2d6a9372, "drm_read" },
	{ 0x3b5dfe58, "drm_gem_fb_create_with_dirty" },
	{ 0x2d6e52c7, "drm_gem_dma_dumb_create" },
	{ 0xeacedcb4, "driver_unregister" },
	{ 0xe8a034df, "drm_dev_exit" },
	{ 0xa7248f47, "__devm_drm_dev_alloc" },
	{ 0x5f754e5a, "memset" },
	{ 0x7a5d0700, "_dev_warn" },
	{ 0x596fccf7, "drm_fb_xrgb8888_to_rgb888" },
	{ 0x97934ecf, "del_timer_sync" },
	{ 0x774d21da, "drm_fbdev_generic_setup" },
	{ 0x6f9af99d, "drm_atomic_helper_connector_duplicate_state" },
	{ 0xd080fb2a, "drm_simple_display_pipe_init" },
	{ 0x5988b0ac, "drm_connector_cleanup" },
	{ 0x526c3a6c, "jiffies" },
	{ 0x3780680a, "dma_set_coherent_mask" },
	{ 0xff46c2c8, "param_set_int" },
	{ 0x62f8d6e5, "drm_gem_fb_begin_cpu_access" },
	{ 0xae353d77, "arm_copy_from_user" },
	{ 0xc6f46339, "init_timer_key" },
	{ 0xb1ad28e0, "__gnu_mcount_nc" },
	{ 0xc09e10da, "__spi_register_driver" },
	{ 0xb1b939e, "kmemdup" },
	{ 0xf6b40bef, "devm_gpiod_get" },
	{ 0x3efa608e, "drm_helper_probe_single_connector_modes" },
	{ 0xf7802486, "__aeabi_uidivmod" },
	{ 0xb50b8fbc, "dma_set_mask" },
	{ 0x2539d863, "drm_atomic_helper_connector_reset" },
	{ 0xdd3ba0bf, "dev_err_probe" },
	{ 0x98f5cdee, "drm_mode_config_reset" },
	{ 0xd6d9627d, "drm_gem_dma_prime_import_sg_table_vmap" },
	{ 0x5995f766, "kmalloc_trace" },
	{ 0xfcf71b9b, "param_get_int" },
	{ 0x9f78379e, "drm_dev_register" },
	{ 0xff178f6, "__aeabi_idivmod" },
	{ 0x2d6fcc06, "__kmalloc" },
	{ 0xe702d4c8, "kmalloc_caches" },
	{ 0xe0838d17, "drm_release" },
	{ 0xc84d16dc, "module_layout" },
};

MODULE_INFO(depends, "drm,drm_kms_helper,drm_dma_helper");


MODULE_INFO(srcversion, "78FBC430EDBA0C50D608C1C");
