#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

#ifdef CONFIG_UNWINDER_ORC
#include <asm/orc_header.h>
ORC_HEADER;
#endif

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

KSYMTAB_FUNC(sharp_memory_set_invert, "_gpl", "");
KSYMTAB_FUNC(sharp_memory_add_overlay, "_gpl", "");
KSYMTAB_FUNC(sharp_memory_remove_overlay, "_gpl", "");
KSYMTAB_FUNC(sharp_memory_show_overlay, "_gpl", "");
KSYMTAB_FUNC(sharp_memory_hide_overlay, "_gpl", "");
KSYMTAB_FUNC(sharp_memory_clear_overlays, "_gpl", "");

SYMBOL_CRC(sharp_memory_set_invert, 0x78e91708, "_gpl");
SYMBOL_CRC(sharp_memory_add_overlay, 0x089128f7, "_gpl");
SYMBOL_CRC(sharp_memory_remove_overlay, 0x8952956f, "_gpl");
SYMBOL_CRC(sharp_memory_show_overlay, 0x14b1f60d, "_gpl");
SYMBOL_CRC(sharp_memory_hide_overlay, 0xc1945636, "_gpl");
SYMBOL_CRC(sharp_memory_clear_overlays, 0x5051489f, "_gpl");

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xb706ee0b, "drm_open" },
	{ 0xf1470b35, "drm_poll" },
	{ 0xa4d29344, "drm_gem_fb_end_cpu_access" },
	{ 0x3ea68f09, "drm_dev_enter" },
	{ 0xd4925fdd, "devm_kmalloc" },
	{ 0x66b4dcdb, "gpiod_set_value" },
	{ 0xd22be210, "drm_plane_enable_fb_damage_clips" },
	{ 0x62cc8a0b, "drm_atomic_helper_shutdown" },
	{ 0x37a0cba, "kfree" },
	{ 0xf0605c89, "drm_connector_helper_get_modes_fixed" },
	{ 0xc3055d20, "usleep_range_state" },
	{ 0x9247e67c, "devm_gpiod_get_optional" },
	{ 0x82ee90dc, "timer_delete_sync" },
	{ 0x77cda50e, "drm_fb_dma_get_gem_obj" },
	{ 0x3e2cdceb, "drmm_mode_config_init" },
	{ 0x43eb3eab, "devm_gpiod_put" },
	{ 0x122c3a7e, "_printk" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xa2541ddf, "drm_atomic_helper_commit" },
	{ 0xc7712d2c, "drm_atomic_helper_check" },
	{ 0x108e71ef, "drm_atomic_helper_connector_destroy_state" },
	{ 0x827d53df, "drm_gem_mmap" },
	{ 0x85039e3b, "drm_ioctl" },
	{ 0x63b049d6, "spi_sync" },
	{ 0x56d8edb0, "drm_dev_unplug" },
	{ 0xd84a6a58, "drm_connector_init" },
	{ 0x8c8569cb, "kstrtoint" },
	{ 0x872fbe41, "drm_atomic_helper_damage_merged" },
	{ 0xc38c83b8, "mod_timer" },
	{ 0x37cdfe3b, "noop_llseek" },
	{ 0xdb14bf95, "drm_read" },
	{ 0xe8b765d2, "drm_gem_fb_create_with_dirty" },
	{ 0x2600c578, "drm_gem_dma_dumb_create" },
	{ 0x21f25246, "driver_unregister" },
	{ 0xe8a034df, "drm_dev_exit" },
	{ 0x1a9aefdc, "__devm_drm_dev_alloc" },
	{ 0xdcb764ad, "memset" },
	{ 0xcfb1ca3f, "_dev_warn" },
	{ 0x1f7df7c, "drm_fb_xrgb8888_to_rgb888" },
	{ 0x73876890, "drm_fbdev_generic_setup" },
	{ 0x1da21a9, "drm_atomic_helper_connector_duplicate_state" },
	{ 0xd5ace8eb, "drm_simple_display_pipe_init" },
	{ 0x78eb9762, "drm_connector_cleanup" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x75a47ff7, "dma_set_coherent_mask" },
	{ 0x2a919e16, "param_set_int" },
	{ 0x1a1a1555, "drm_gem_fb_begin_cpu_access" },
	{ 0xc6f46339, "init_timer_key" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x10419494, "__spi_register_driver" },
	{ 0x66b4cc41, "kmemdup" },
	{ 0x2ff415eb, "devm_gpiod_get" },
	{ 0xabd1b575, "drm_helper_probe_single_connector_modes" },
	{ 0x12a4e128, "__arch_copy_from_user" },
	{ 0x2aff2c72, "dma_set_mask" },
	{ 0xb5e1f8a8, "drm_atomic_helper_connector_reset" },
	{ 0xfd0082c0, "dev_err_probe" },
	{ 0xbb5523e7, "drm_mode_config_reset" },
	{ 0xe108896d, "drm_gem_dma_prime_import_sg_table_vmap" },
	{ 0x3ae23b9a, "kmalloc_trace" },
	{ 0x45af4010, "param_get_int" },
	{ 0x10c93ab6, "drm_compat_ioctl" },
	{ 0x90e6ff83, "drm_dev_register" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0x5e5ac9ba, "kmalloc_caches" },
	{ 0x62d482b, "drm_release" },
	{ 0x126bac03, "module_layout" },
};

MODULE_INFO(depends, "drm,drm_kms_helper,drm_dma_helper");


MODULE_INFO(srcversion, "94E604EBB80C4A303790FE2");
